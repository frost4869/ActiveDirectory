﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ActiveDirectoryManagement.Common
{
    public class Assets
    {
        public static readonly string AdminUsername = "phuc.nh";
        public static readonly string AdminPassword = "abc@123";
    }
}